package com.group.exam.calendar.command;

import java.util.Date;

public class CalendarDateCommand {
	public Date startDate;

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	
	
}	
