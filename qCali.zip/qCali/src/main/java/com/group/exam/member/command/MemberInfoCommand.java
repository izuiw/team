package com.group.exam.member.command;

public class MemberInfoCommand {
	private Long memberSeq;
	private String memberId;
	private String memberNickname;
	private String memberRegDay;
	private String memberBirthDay;
	private int memberLevel;
	public Long getMemberSeq() {
		return memberSeq;
	}
	public void setMemberSeq(Long memberSeq) {
		this.memberSeq = memberSeq;
	}
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public String getMemberNickname() {
		return memberNickname;
	}
	public void setMemberNickname(String memberNickname) {
		this.memberNickname = memberNickname;
	}
	public String getMemberRegDay() {
		return memberRegDay;
	}
	public void setMemberRegDay(String memberRegDay) {
		this.memberRegDay = memberRegDay;
	}
	public String getMemberBirthDay() {
		return memberBirthDay;
	}
	public void setMemberBirthDay(String memberBirthDay) {
		this.memberBirthDay = memberBirthDay;
	}
	public int getMemberLevel() {
		return memberLevel;
	}
	public void setMemberLevel(int memberLevel) {
		this.memberLevel = memberLevel;
	}
	
	
}
