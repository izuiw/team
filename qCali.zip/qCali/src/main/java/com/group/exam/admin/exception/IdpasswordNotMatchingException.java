package com.group.exam.admin.exception;

public class IdpasswordNotMatchingException extends RuntimeException{

}
