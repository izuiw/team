package com.group.exam.board.command;

public class BoardLikeCommand{
	private int boardSeq;
	private int heart;
	
	
	public int getBoardSeq() {
		return boardSeq;
	}
	public void setBoardSeq(int boardSeq) {
		this.boardSeq = boardSeq;
	}
	public int getHeart() {
		return heart;
	}
	public void setHeart(int heart) {
		this.heart = heart;
	}

	
	
}