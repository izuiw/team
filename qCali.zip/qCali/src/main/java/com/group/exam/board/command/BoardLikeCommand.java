package com.group.exam.board.command;

public class BoardLikeCommand{
	private Long boardSeq;
	private int heart;
	
	

	public Long getBoardSeq() {
		return boardSeq;
	}
	public void setBoardSeq(Long boardSeq) {
		this.boardSeq = boardSeq;
	}
	public int getHeart() {
		return heart;
	}
	public void setHeart(int heart) {
		this.heart = heart;
	}

	
	
}