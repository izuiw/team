package com.group.exam.member.command;

public class KakaoCommand {
	private String kakaoId;
	
	
	public KakaoCommand() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getKakaoId() {
		return kakaoId;
	}
	public void setKakaoId(String kakaoId) {
		this.kakaoId = kakaoId;
	}

}
