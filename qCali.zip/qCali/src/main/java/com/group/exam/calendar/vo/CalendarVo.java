package com.group.exam.calendar.vo;

public class CalendarVo {
	private Long calendarSeq;
	private Long boardSeq;
	private String calendarDay;
	private Long count;
	
	
	public Long getCount() {
		return count;
	}
	public void setCount(Long count) {
		this.count = count;
	}
	public Long getCalendarSeq() {
		return calendarSeq;
	}
	public void setCalendarSeq(Long calendarSeq) {
		this.calendarSeq = calendarSeq;
	}
	public Long getBoardSeq() {
		return boardSeq;
	}
	public void setBoardSeq(Long boardSeq) {
		this.boardSeq = boardSeq;
	}
	public String getCalendarDay() {
		return calendarDay;
	}
	public void setCalendarDay(String calendarDay) {
		this.calendarDay = calendarDay;
	}
	
	
	
}	
