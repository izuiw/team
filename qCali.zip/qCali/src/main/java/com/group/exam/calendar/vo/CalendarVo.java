package com.group.exam.calendar.vo;

public class CalendarVo {
	private int calendarSeq;
	private String calendarTitle;
	private String calendarDay;
	
	
	public int getCalendarSeq() {
		return calendarSeq;
	}
	public void setCalendarSeq(int calendarSeq) {
		this.calendarSeq = calendarSeq;
	}
	public String getCalendarTitle() {
		return calendarTitle;
	}
	public void setCalendarTitle(String calendarTitle) {
		this.calendarTitle = calendarTitle;
	
	}
	public String getCalendarDay() {
		return calendarDay;
	}
	public void setCalendarDay(String calendarDay) {
		this.calendarDay = calendarDay;
	}
	
}	
