package com.group.exam.member.command;

public class MemberchangeNickname {
	
	private String memberNickname;

	public String getMemberNickname() {
		return memberNickname;
	}

	public void setMemberNickname(String memberNickname) {
		this.memberNickname = memberNickname;
	}
	
	

}
