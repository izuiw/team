package com.group.exam.calendar.vo;

public class CalendarBoardVo {
	private long boardSeq;
	private String boardTitle;
	private String memberNickname;
	private long boardCount;
	private long boardLike;
	private String quesionContent;
	private String boardContent;
	public long getBoardSeq() {
		return boardSeq;
	}
	public void setBoardSeq(long boardSeq) {
		this.boardSeq = boardSeq;
	}
	public String getBoardTitle() {
		return boardTitle;
	}
	public void setBoardTitle(String boardTitle) {
		this.boardTitle = boardTitle;
	}
	public String getMemberNickname() {
		return memberNickname;
	}
	public void setMemberNickname(String memberNickname) {
		this.memberNickname = memberNickname;
	}
	public long getBoardCount() {
		return boardCount;
	}
	public void setBoardCount(long boardCount) {
		this.boardCount = boardCount;
	}
	public long getBoardLike() {
		return boardLike;
	}
	public void setBoardLike(long boardLike) {
		this.boardLike = boardLike;
	}
	public String getQuesionContent() {
		return quesionContent;
	}
	public void setQuesionContent(String quesionContent) {
		this.quesionContent = quesionContent;
	}
	public String getBoardContent() {
		return boardContent;
	}
	public void setBoardContent(String boardContent) {
		this.boardContent = boardContent;
	}
	@Override
	public String toString() {
		return "CalendarBoardVo [boardSeq=" + boardSeq + ", boardTitle=" + boardTitle + ", memberNickname="
				+ memberNickname + ", boardCount=" + boardCount + ", boardLike=" + boardLike + ", quesionContent="
				+ quesionContent + ", boardContent=" + boardContent + "]";
	}
	
}
